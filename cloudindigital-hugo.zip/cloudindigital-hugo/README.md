
---


## README.md (quick instructions)


``markdown
# CloudInDigital — Hugo template


1. Copy this folder to your local machine.
2. `git init` → create repo on GitHub → push.
3. Import repository in Vercel (Framework: Hugo, Build: `hugo`, Output: `public`).
4. In Cloudflare DNS: add records as Vercel instructs (A: 76.76.21.21 / CNAME for www). Set proxy to DNS only (grey cloud) for apex.


After deploy, site will be live at `https://cloudindigital.org` (when DNS propagates).